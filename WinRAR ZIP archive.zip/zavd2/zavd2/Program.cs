﻿using System;
using System.Text.RegularExpressions;

public class Program
{
    public static void Main()
    {
        string input = "Котик спить на диванi. Котики граються з м'ячиком. Котика звати Мурка.";
        string output = ReplaceDefinedExpressions(input);
        Console.WriteLine(output);
    }

    public static string ReplaceDefinedExpressions(string input)
    {
        string pattern = @"\bкотик\w*\b";
        string replacement = "кошеня";
        string output = Regex.Replace(input, pattern, replacement, RegexOptions.IgnoreCase);
        return output;
    }
}