﻿using System;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        Console.WriteLine("Введіть логiн:");
        string login = Console.ReadLine();

        if (CheckLogin(login))
            Console.WriteLine("Логiн коректний");
        else
            Console.WriteLine("Логiн некоректний");
    }

    static bool CheckLogin(string login)
    {
        Regex regex = new Regex(@"^[a-zA-Z][a-zA-Z0-9]{1,9}$");
        return regex.IsMatch(login);
    }
}